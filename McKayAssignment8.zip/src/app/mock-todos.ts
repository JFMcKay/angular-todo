import { Todo } from './todo';

export const TODOS: Todo[] = [
    {id: 1, name:'Go shopping'},
    {id: 2, name:'Feed the cat'},
    {id: 3, name:'Walk the dog'},
    {id: 4, name:'Buy gas'},
    {id: 5, name:'Take a break'},
    {id: 6, name:'Call Mommy'}
]
